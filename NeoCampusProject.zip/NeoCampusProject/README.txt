- README -

/ ! \ L'executable doit se lancer dans le meme dossier que le fichier de gestion des salle : " format_bat" / ! \

Mon collegue Karim SALAMA a rendu un projet contenant une erreur. Veuillez donc ignorer son depot et prendre en compte ma version corrigeant cette erreur.

Groupe 3.1 : 

Jouaneau Gatien
Salama Karim
Lary Guillaume
Washbrook Thomas
